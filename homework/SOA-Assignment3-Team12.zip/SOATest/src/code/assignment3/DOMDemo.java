package code.assignment3;

import java.io.File;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class DOMDemo {
	public static void main(String[] args) {
		// step1:���һ��DocumentBuilderFactory
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		// step2:���һ��DocumentBuilder
		DocumentBuilder db = null;
		try {
			db = factory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// step3:�½�һ��Document����
		Document document = db.newDocument();
		// step4:����һ�����ڵ�
		Element studentList = document.createElement("ѧ���б�");
		// step5:���ø��ڵ�����(����еĻ���
		studentList.setAttribute("xmls", "http://jw.nju.edu.cn/schema");
		// step6:�����ӽڵ�
		Element student = document.createElement("ѧ��");
		// step7:���ڵ�����ӽڵ�
		studentList.appendChild(student);
		// step8:document�������ڵ�
		document.appendChild(studentList);

		// step9:���һ��TransformerFactory����
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		// step10:���һ��Transformer����
		Transformer transformer = null;
		try {
			transformer = transformerFactory.newTransformer();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// step11:����Transformer���������
		Properties oprops = new Properties();
		oprops.put(OutputKeys.ENCODING, "UTF-8");
		oprops.put(OutputKeys.OMIT_XML_DECLARATION, "no");
		oprops.put(OutputKeys.INDENT, "yes");
		oprops.put(OutputKeys.METHOD, "xml");
		transformer.setOutputProperties(oprops);

		String path = "XML3.xml";
		DOMSource xmlSource = new DOMSource(document);

		// step12:�������洢Ŀ�����
		Result outputTarget = new StreamResult(new File(path));
		// step13:������Ӧ��xml�ļ�
		try {
			transformer.transform(xmlSource, outputTarget);
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
